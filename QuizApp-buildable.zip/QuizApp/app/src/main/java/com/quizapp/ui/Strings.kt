package com.quizapp.ui

import android.content.Context
import androidx.compose.runtime.staticCompositionLocalOf
import kotlinx.coroutines.flow.MutableStateFlow

/** Theme (0 system / 1 light / 2 dark), font scale and UI language — persisted, observed by MainActivity. */
class AppPrefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
    val theme = MutableStateFlow(p.getInt("theme", 0))
    val fontScale = MutableStateFlow(p.getFloat("font", 1f))
    val lang = MutableStateFlow(p.getString("lang", "en")!!)
    fun setTheme(v: Int) { p.edit().putInt("theme", v).apply(); theme.value = v }
    fun setFontScale(v: Float) { p.edit().putFloat("font", v).apply(); fontScale.value = v }
    fun setLang(v: String) { p.edit().putString("lang", v).apply(); lang.value = v }
}

/** UI strings (English defaults). Question/explanation content keeps whatever language it was imported in. */
data class Strings(
    val subjects: String = "Subjects", val majorTopics: String = "Major topics", val subtopics: String = "Subtopics", val quizSets: String = "Quiz sets",
    val previous: String = "Previous", val next: String = "Next", val finish: String = "Finish", val submit: String = "Submit",
    val correctAnswer: String = "Correct Answer", val explanation: String = "Explanation", val application: String = "Application",
    val result: String = "Result", val score: String = "Score", val accuracy: String = "Accuracy", val time: String = "Time", val backHome: String = "Back to Home",
    val exportPdf: String = "Export result as PDF", val settings: String = "Settings", val theme: String = "Theme", val system: String = "System",
    val light: String = "Light", val dark: String = "Dark", val fontSize: String = "Font size", val language: String = "Language",
    val analytics: String = "Analytics", val attempts: String = "attempts", val streak: String = "Streak", val bestStreak: String = "Best",
    val last14: String = "Accuracy — last 14 active days", val weakTopics: String = "Weak topics", val practiceAi: String = "Practice with AI", val noData: String = "No attempts yet.")

val EN = Strings()
val HI = Strings(
    subjects = "विषय", majorTopics = "प्रमुख टॉपिक", subtopics = "उप-टॉपिक", quizSets = "क्विज़ सेट", previous = "पिछला", next = "अगला", finish = "समाप्त करें", submit = "जमा करें",
    correctAnswer = "सही उत्तर", explanation = "व्याख्या", application = "अनुप्रयोग", result = "परिणाम", score = "स्कोर", accuracy = "सटीकता", time = "समय", backHome = "होम पर जाएँ",
    exportPdf = "परिणाम PDF में सहेजें", settings = "सेटिंग्स", theme = "थीम", system = "सिस्टम", light = "लाइट", dark = "डार्क", fontSize = "फ़ॉन्ट आकार", language = "भाषा",
    analytics = "विश्लेषण", attempts = "प्रयास", streak = "स्ट्रीक", bestStreak = "सर्वश्रेष्ठ", last14 = "सटीकता — पिछले 14 सक्रिय दिन", weakTopics = "कमज़ोर टॉपिक",
    practiceAi = "AI से अभ्यास करें", noData = "अभी कोई प्रयास नहीं।")
val LocalS = staticCompositionLocalOf { EN }
