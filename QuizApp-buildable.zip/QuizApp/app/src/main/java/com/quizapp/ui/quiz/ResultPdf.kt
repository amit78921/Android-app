package com.quizapp.ui.quiz

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import com.quizapp.ui.Strings
import java.io.OutputStream

/** Plain A4 report via android.graphics.pdf (StaticLayout handles Devanagari shaping). */
object ResultPdf {
    fun write(out: OutputStream, blocks: List<Pair<String, Boolean>>) {
        val w = 595; val h = 842; val m = 40
        val normal = TextPaint().apply { textSize = 11f; isAntiAlias = true; color = Color.BLACK }
        val bold = TextPaint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
        val doc = PdfDocument(); var n = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create()); var y = m.toFloat()
        for ((text, isBold) in blocks) {
            val lay = StaticLayout.Builder.obtain(text, 0, text.length, if (isBold) bold else normal, w - 2 * m).build()
            if (y + lay.height > h - m) { doc.finishPage(page); page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, ++n).create()); y = m.toFloat() }
            page.canvas.save(); page.canvas.translate(m.toFloat(), y); lay.draw(page.canvas); page.canvas.restore(); y += lay.height + 6
        }
        doc.finishPage(page); doc.writeTo(out); doc.close()
    }
}

fun QuizViewModel.reportBlocks(S: Strings): List<Pair<String, Boolean>> {
    val correct = answers.count { (k, l) -> questions[k].correct == l }; val acc = if (answers.isEmpty()) 0 else correct * 100 / answers.size; val secs = totalMs / 1000
    val out = mutableListOf(S.result to true, "${S.score}: $correct / ${questions.size}" to false,
        "${S.accuracy}: $acc%    ${S.time}: %d:%02d".format(secs / 60, secs % 60) to false, path to false, "" to false)
    answers.filter { (k, l) -> questions[k].correct != l }.keys.sorted().forEach { k ->
        val q = questions[k]
        out += "Q${q.number}. ${q.text}" to true
        out += "${answers[k]} ✗   ${S.correctAnswer}: ${q.correct}" to false
        q.explanation?.let { out += it to false }
    }
    return out
}
