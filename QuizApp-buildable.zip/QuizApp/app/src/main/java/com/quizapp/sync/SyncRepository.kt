package com.quizapp.sync

import android.content.SharedPreferences
import androidx.room.withTransaction
import com.google.firebase.Timestamp
import com.google.firebase.firestore.*
import com.quizapp.auth.AuthManager
import com.quizapp.data.*
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.Date

/**
 * Firestore layout (all under users/{uid}):  sets/{setUid} = set + questions · state/{setUid} = bookmarks · attempts/{attemptUid}
 * Outbox = Room flags (QuizSet.dirty / bookmarksDirty, Attempt.synced). Doc ids are deterministic, so retries are idempotent.
 * Conflicts: sets and attempts are append-only; bookmarks are last-writer-wins per set.
 */
class SyncRepository(private val db: AppDatabase, private val auth: AuthManager, private val prefs: SharedPreferences) {
    private val dao = db.dao(); private val fs = FirebaseFirestore.getInstance()
    private fun col(n: String) = fs.collection("users").document(auth.uid!!).collection(n)
    private suspend fun <T> net(b: suspend () -> T) = withTimeout(30_000) { b() }

    suspend fun syncAll() { if (auth.isSignedIn) { push(); pull() } }

    private suspend fun push() {
        for (s in dao.dirtySets()) {
            val n = dao.names(s.id) ?: continue
            val qs = dao.questions(s.id).map { mapOf("n" to it.number, "text" to it.text, "a" to it.optA, "b" to it.optB, "c" to it.optC, "d" to it.optD,
                "correct" to it.correct, "explanation" to it.explanation, "application" to it.application, "review" to it.needsReview) }
            net { col("sets").document(s.uid).set(mapOf("title" to s.title, "createdAt" to s.createdAt, "subject" to n.subject, "topic" to n.topic,
                "subtopic" to n.subtopic, "questions" to qs, "updatedAt" to FieldValue.serverTimestamp())).await() }   // 1 MiB doc limit ≈ several hundred questions
            dao.clearDirty(s.id)
        }
        for (s in dao.bookmarkDirtySets()) {
            net { col("state").document(s.uid).set(mapOf("bookmarks" to dao.bookmarkedNumbers(s.id))).await() }; dao.clearBmDirty(s.id)
        }
        while (true) {
            val a = dao.unsyncedAttempts(); if (a.isEmpty()) break
            val b = fs.batch()
            a.forEach { b.set(col("attempts").document(it.uid), mapOf("setUid" to it.setUid, "number" to it.number, "selected" to it.selected,
                "isCorrect" to it.isCorrect, "timeMs" to it.timeMs, "mode" to it.mode, "ts" to it.ts)) }
            net { b.commit().await() }; dao.markSynced(a.map { it.uid })
        }
    }

    @Suppress("UNCHECKED_CAST")
    private suspend fun pull() {
        val since = prefs.getLong("setsSince", 0L); var maxSet = since
        for (d in net { col("sets").whereGreaterThan("updatedAt", Timestamp(Date(since))).get().await() }) {
            d.getTimestamp("updatedAt")?.let { maxSet = maxOf(maxSet, it.toDate().time) }
            if (dao.setIdByUid(d.id) != null) continue                     // edits to existing sets from other devices aren't merged yet
            db.withTransaction {
                val s = d.getString("subject")!!.let { n -> dao.subjectId(n) ?: dao.insert(Subject(name = n)) }
                val t = d.getString("topic")!!.let { n -> dao.topicId(s, n) ?: dao.insert(MajorTopic(subjectId = s, name = n)) }
                val st = d.getString("subtopic")!!.let { n -> dao.subtopicId(t, n) ?: dao.insert(Subtopic(majorTopicId = t, name = n)) }
                val id = dao.insert(QuizSet(subtopicId = st, title = d.getString("title")!!, createdAt = d.getLong("createdAt") ?: 0, uid = d.id, dirty = false))
                dao.insertQuestions((d.get("questions") as List<Map<String, Any?>>).map {
                    Question(quizSetId = id, number = (it["n"] as Long).toInt(), text = it["text"] as String, optA = it["a"] as String, optB = it["b"] as String,
                        optC = it["c"] as String, optD = it["d"] as String, correct = it["correct"] as String, explanation = it["explanation"] as String?,
                        application = it["application"] as String?, needsReview = it["review"] as? Boolean ?: false) })
            }
        }
        prefs.edit().putLong("setsSince", maxSet).apply()

        for (d in net { col("state").get().await() }) {
            val id = dao.setIdByUid(d.id) ?: continue
            if (dao.bmDirty(id)) continue                                   // local unsynced change wins
            dao.applyBookmarks(id, (d.get("bookmarks") as? List<Long>).orEmpty().map { it.toInt() }); dao.clearBmDirty(id)
        }

        val aSince = prefs.getLong("attemptsSince", 0L); var maxA = aSince
        for (d in net { col("attempts").whereGreaterThan("ts", aSince).get().await() }) {
            val ts = d.getLong("ts") ?: continue; maxA = maxOf(maxA, ts)
            val setId = dao.setIdByUid(d.getString("setUid")!!) ?: continue
            val qid = dao.questionId(setId, d.getLong("number")!!.toInt()) ?: continue
            if (dao.attemptCount(d.id) == 0) dao.insert(Attempt(questionId = qid, quizSetId = setId, selected = d.getString("selected")!!, isCorrect = d.getBoolean("isCorrect")!!,
                timeMs = d.getLong("timeMs")!!, mode = d.getString("mode")!!, ts = ts, uid = d.id, synced = true))
        }
        prefs.edit().putLong("attemptsSince", maxA).apply()
    }
}
