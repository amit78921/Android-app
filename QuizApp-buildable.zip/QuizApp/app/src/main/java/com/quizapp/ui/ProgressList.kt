package com.quizapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.quizapp.data.Progress
import kotlin.math.roundToInt

/** One list screen reused at every level: Subject → Major Topic → Subtopic → Quiz Set. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressList(title: String, items: List<Progress>, onBack: (() -> Unit)? = null, onImport: (() -> Unit)? = null, onSettings: (() -> Unit)? = null, onAnalytics: (() -> Unit)? = null, onClick: (Long) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text(title) }, actions = { onAnalytics?.let { IconButton(it) { Icon(Icons.Filled.Insights, "Analytics") } }; onSettings?.let { IconButton(it) { Icon(Icons.Filled.Settings, "Settings") } } }, navigationIcon = { onBack?.let { IconButton(it) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } } }) },
        floatingActionButton = { onImport?.let { FloatingActionButton(it) { Icon(Icons.Filled.Add, "Import PDF") } } }
    ) { pad ->
        if (items.isEmpty()) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("Nothing here yet — tap + to import a quiz.") }
        else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { it.id }) { p ->
                Card(onClick = { onClick(p.id) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium)
                        LinearProgressIndicator(progress = { if (p.total == 0) 0f else p.attempted / p.total.toFloat() }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                        Text("${p.attempted}/${p.total} attempted · ${p.accuracy.roundToInt()}% accuracy", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
