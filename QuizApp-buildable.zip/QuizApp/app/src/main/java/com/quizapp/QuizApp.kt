package com.quizapp

import android.app.Application
import androidx.room.Room
import com.quizapp.data.AppDatabase
import com.quizapp.ai.*
import com.quizapp.auth.AuthManager
import com.quizapp.data.*
import com.quizapp.sync.*
import com.quizapp.ui.AppPrefs
import com.quizapp.pdf.*

/** Manual DI container (kept simple; swap for Hilt if you prefer). */
class QuizApp : Application() {
    val db by lazy { Room.databaseBuilder(this, AppDatabase::class.java, "quiz.db").addMigrations(MIGRATION_1_2).addCallback(SyncTriggers).build() }
    val auth by lazy { AuthManager(this) }
    val net by lazy { ConnectivityObserver(this) }
    val sync by lazy { SyncRepository(db, auth, getSharedPreferences("sync", MODE_PRIVATE)) }
    val prefs by lazy { AppPrefs(this) }
    val keys by lazy { SecureKeyStore(this) }
    val gemini by lazy { GeminiService(keys, db.dao()) { auth.isSignedIn } }   // Phase 4: pass { signedIn } to block guests
    val importRepo by lazy { ImportRepository(db, PdfTextExtractor(this)) }
}
