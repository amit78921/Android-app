package com.quizapp.ui.quiz

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.quizapp.ai.*
import com.quizapp.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Practice: answer locks instantly and is saved. Test: answers can change until submit; saved + revealed on submit. */
class QuizViewModel(private val dao: QuizDao, private val setId: Long, val practice: Boolean, mins: Int, private val gemini: GeminiService) : ViewModel() {
    val questions = mutableStateListOf<Question>()
    val answers = mutableStateMapOf<Int, String>()
    private val spent = mutableMapOf<Int, Long>()
    var index by mutableIntStateOf(0); private set
    var finished by mutableStateOf(false); private set
    var remaining by mutableIntStateOf(mins * 60); private set
    var path by mutableStateOf(""); private set
    val timed = mins > 0
    val totalMs get() = spent.values.sum()
    private var mark = System.currentTimeMillis()

    init {
        viewModelScope.launch {
            questions.addAll(dao.questions(setId)); path = dao.path(setId).orEmpty(); mark = System.currentTimeMillis()
            if (timed) { while (remaining > 0 && !finished) { delay(1000); remaining-- }; finish() }
        }
    }

    fun locked(i: Int) = finished || (practice && i in answers)
    private fun touch() { val n = System.currentTimeMillis(); spent[index] = (spent[index] ?: 0) + n - mark; mark = n }
    fun go(i: Int) { aiError = null; touch(); index = i.coerceIn(0, questions.lastIndex) }

    fun answer(letter: String) {
        if (locked(index)) return
        touch(); answers[index] = letter
        if (practice) viewModelScope.launch { record(index) }
    }
    fun finish() {
        if (finished || questions.isEmpty()) return
        touch(); finished = true
        if (!practice) viewModelScope.launch { answers.keys.toList().forEach { record(it) } }
    }
    private suspend fun record(i: Int) {
        val q = questions[i]
        dao.insert(Attempt(questionId = q.id, quizSetId = setId, selected = answers[i]!!, isCorrect = answers[i] == q.correct,
            timeMs = spent[i] ?: 0, mode = if (practice) "practice" else "test"))
    }
    fun toggleBookmark() {
        val q = questions[index]; questions[index] = q.copy(bookmarked = !q.bookmarked)
        viewModelScope.launch { dao.bookmark(q.id, !q.bookmarked) }
    }

    // ---- Gemini ----
    var aiBusy by mutableStateOf(false); private set
    var aiError by mutableStateOf<String?>(null); private set
    var practiceMsg by mutableStateOf<String?>(null); private set
    val verdicts = mutableStateMapOf<Int, Verdict>()
    val chats = mutableStateMapOf<Int, List<Pair<String, String>>>()

    private fun ai(block: suspend () -> Unit) = viewModelScope.launch {
        aiBusy = true; aiError = null
        runCatching { block() }.onFailure { aiError = it.message ?: "AI request failed (check internet / API key)" }
        aiBusy = false
    }
    fun explain(force: Boolean) { val i = index; val q = questions[i]; ai { val (e, a) = gemini.explain(q, force); questions[i] = questions[i].copy(explanation = e, application = a) } }
    fun verify() { val i = index; val q = questions[i]; ai { verdicts[i] = gemini.verify(q) } }
    fun useAiAnswer() {
        val i = index; val v = verdicts[i] ?: return
        questions[i] = questions[i].copy(correct = v.answer); verdicts.remove(i)
        viewModelScope.launch { dao.setCorrect(questions[i].id, v.answer) }
    }
    fun ask(msg: String) { val i = index; val q = questions[i]; val h = chats[i].orEmpty(); ai { chats[i] = h + (msg to gemini.ask(q, h, msg)) } }
    fun practiceFromMistakes() {
        val wrong = answers.filter { (k, l) -> questions[k].correct != l }.keys.map { questions[it] }
        ai { gemini.practice(setId, wrong); practiceMsg = "Created an AI practice set in this subtopic — find it under Quiz sets." }
    }
}
