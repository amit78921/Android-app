package com.quizapp.data

import androidx.room.*
import java.util.UUID

@Entity data class Subject(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(foreignKeys = [ForeignKey(entity = Subject::class, parentColumns = ["id"], childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE)], indices = [Index("subjectId")])
data class MajorTopic(@PrimaryKey(autoGenerate = true) val id: Long = 0, val subjectId: Long, val name: String)

@Entity(foreignKeys = [ForeignKey(entity = MajorTopic::class, parentColumns = ["id"], childColumns = ["majorTopicId"], onDelete = ForeignKey.CASCADE)], indices = [Index("majorTopicId")])
data class Subtopic(@PrimaryKey(autoGenerate = true) val id: Long = 0, val majorTopicId: Long, val name: String)

@Entity(foreignKeys = [ForeignKey(entity = Subtopic::class, parentColumns = ["id"], childColumns = ["subtopicId"], onDelete = ForeignKey.CASCADE)], indices = [Index("subtopicId")])
data class QuizSet(@PrimaryKey(autoGenerate = true) val id: Long = 0, val subtopicId: Long, val title: String,
                   val timerSeconds: Int? = null, val createdAt: Long = System.currentTimeMillis(),
                   val uid: String = UUID.randomUUID().toString(), val dirty: Boolean = true, val bookmarksDirty: Boolean = false)

@Entity(foreignKeys = [ForeignKey(entity = QuizSet::class, parentColumns = ["id"], childColumns = ["quizSetId"], onDelete = ForeignKey.CASCADE)], indices = [Index("quizSetId")])
data class Question(@PrimaryKey(autoGenerate = true) val id: Long = 0, val quizSetId: Long, val number: Int, val text: String,
                    val optA: String, val optB: String, val optC: String, val optD: String,
                    val correct: String, val explanation: String? = null, val application: String? = null,
                    val bookmarked: Boolean = false, val needsReview: Boolean = false)

@Entity(indices = [Index("questionId"), Index("quizSetId")])
data class Attempt(@PrimaryKey(autoGenerate = true) val id: Long = 0, val questionId: Long, val quizSetId: Long,
                   val selected: String, val isCorrect: Boolean, val timeMs: Long, val mode: String, val ts: Long = System.currentTimeMillis(),
                   val uid: String = UUID.randomUUID().toString(), val synced: Boolean = false)

/** Gemini response cache: key = "<type>:<questionId>" so each AI call happens once. */
@Entity data class AiCache(@PrimaryKey val key: String, val response: String, val ts: Long = System.currentTimeMillis())
