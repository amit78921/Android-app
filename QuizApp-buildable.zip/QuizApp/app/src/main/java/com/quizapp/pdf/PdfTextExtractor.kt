package com.quizapp.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.PDFTextStripperByArea
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/** On-device extraction first (PdfBox); falls back to ML Kit OCR (Latin + Devanagari) for scanned PDFs. */
class PdfTextExtractor(private val ctx: Context) {
    /** flat = reading order; columns = each page split into left/right halves. The parser picks whichever yields more questions. */
    data class Result(val flat: String, val columns: String, val ocr: Boolean)

    suspend fun extract(uri: Uri): Result = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(ctx)
        ctx.contentResolver.openInputStream(uri)!!.use { s ->
            PDDocument.load(s).use { doc ->
                val flat = PDFTextStripper().apply { sortByPosition = true }.getText(doc)
                if (flat.count { !it.isWhitespace() } > 40 * doc.numberOfPages) Result(flat, columns(doc), false)
                else ocr(uri).let { Result(it, it, true) }
            }
        }
    }

    private fun columns(doc: PDDocument): String {
        val sb = StringBuilder()
        for (i in 0 until doc.numberOfPages) {
            val page = doc.getPage(i); val w = page.mediaBox.width; val h = page.mediaBox.height
            val st = PDFTextStripperByArea().apply { sortByPosition = true }
            st.addRegion("L", RectF(0f, 0f, w / 2, h)); st.addRegion("R", RectF(w / 2, 0f, w / 2, h))
            st.extractRegions(page)
            sb.appendLine(st.getTextForRegion("L")).appendLine(st.getTextForRegion("R"))
        }
        return sb.toString()
    }

    private suspend fun ocr(uri: Uri): String {
        val rec = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")!!
        val r = PdfRenderer(pfd); val sb = StringBuilder()
        try {
            for (i in 0 until r.pageCount) {
                val p = r.openPage(i)
                try {
                    val bmp = Bitmap.createBitmap(p.width * 2, p.height * 2, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.WHITE) }
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    sb.appendLine(rec.process(InputImage.fromBitmap(bmp, 0)).await().text)
                } finally { p.close() }
            }
        } finally { r.close(); pfd.close() }
        return sb.toString()
    }
}
