package com.quizapp.auth

import android.content.Context
import androidx.credentials.*
import com.google.android.libraries.identity.googleid.*
import com.google.firebase.auth.*
import com.quizapp.R
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await

sealed interface AuthState {
    data object SignedOut : AuthState
    data object Guest : AuthState
    data class SignedIn(val uid: String, val email: String?) : AuthState
}

/** Google Sign-In via Credential Manager → Firebase Auth. Guest mode = local-only (no sync, no AI). */
class AuthManager(private val ctx: Context) {
    private val fb = FirebaseAuth.getInstance()
    private val prefs = ctx.getSharedPreferences("auth", Context.MODE_PRIVATE)
    private val guest = MutableStateFlow(prefs.getBoolean("guest", false))
    private val user = callbackFlow {
        val l = FirebaseAuth.AuthStateListener { trySend(it.currentUser) }
        fb.addAuthStateListener(l); awaitClose { fb.removeAuthStateListener(l) }
    }
    private fun resolve(u: FirebaseUser?, g: Boolean): AuthState = when {
        u != null -> AuthState.SignedIn(u.uid, u.email); g -> AuthState.Guest; else -> AuthState.SignedOut
    }
    val state: StateFlow<AuthState> = combine(user, guest, ::resolve)
        .stateIn(CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate), SharingStarted.Eagerly, resolve(fb.currentUser, guest.value))
    val uid get() = fb.currentUser?.uid
    val isSignedIn get() = uid != null

    private fun setGuest(v: Boolean) { prefs.edit().putBoolean("guest", v).apply(); guest.value = v }
    fun continueAsGuest() = setGuest(true)

    suspend fun signIn(activity: Context) {
        val opt = GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false).setServerClientId(ctx.getString(R.string.default_web_client_id)).build()
        val res = CredentialManager.create(activity).getCredential(activity, GetCredentialRequest.Builder().addCredentialOption(opt).build())
        val token = GoogleIdTokenCredential.createFrom(res.credential.data).idToken
        fb.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
        setGuest(false)
    }
    suspend fun signOut() {
        fb.signOut(); setGuest(false)
        runCatching { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) }
    }
}
