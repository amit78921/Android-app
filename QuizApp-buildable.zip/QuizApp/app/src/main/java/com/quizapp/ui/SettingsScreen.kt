package com.quizapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quizapp.ai.SecureKeyStore
import com.quizapp.auth.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(keys: SecureKeyStore, auth: AuthManager, prefs: AppPrefs, onBack: () -> Unit) {
    val st by auth.state.collectAsStateWithLifecycle(); val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }; var saved by remember { mutableStateOf(keys.get() != null) }
    Scaffold(topBar = { TopAppBar(title = { Text(LocalS.current.settings) }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            (st as? AuthState.SignedIn)?.let { Text("Signed in as ${it.email}"); OutlinedButton({ scope.launch { auth.signOut() } }) { Text("Sign out") } }
                ?: Column { Text("Guest mode — no sync or AI"); Button({ scope.launch { runCatching { auth.signIn(ctx) } } }) { Text("Sign in with Google") } }
            HorizontalDivider()
            val S = LocalS.current; val theme by prefs.theme.collectAsStateWithLifecycle(); val scale by prefs.fontScale.collectAsStateWithLifecycle(); val lang by prefs.lang.collectAsStateWithLifecycle()
            Text(S.theme, style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(S.system, S.light, S.dark).forEachIndexed { i, l -> FilterChip(theme == i, { prefs.setTheme(i) }, { Text(l) }) } }
            Text("${S.fontSize}: ${(scale * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(scale, { prefs.setFontScale((it * 20).roundToInt() / 20f) }, valueRange = 0.8f..1.5f)
            Text(S.language, style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(lang == "en", { prefs.setLang("en") }, { Text("English") }); FilterChip(lang == "hi", { prefs.setLang("hi") }, { Text("हिन्दी") }) }
            HorizontalDivider()
            Text(if (saved) "Gemini API key: saved (encrypted on this device)" else "No Gemini API key saved")
            OutlinedTextField(key, { key = it }, label = { Text("Gemini API key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ keys.set(key); key = ""; saved = true }, enabled = key.isNotBlank()) { Text("Save") }
                if (saved) TextButton({ keys.clear(); saved = false }) { Text("Remove") }
            }
            Text("Create a key at aistudio.google.com. It is stored with Keystore-backed encryption and is only sent to Google in AI requests.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
