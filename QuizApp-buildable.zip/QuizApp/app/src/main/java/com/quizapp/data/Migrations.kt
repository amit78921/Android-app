package com.quizapp.data

import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE QuizSet ADD COLUMN uid TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE QuizSet ADD COLUMN dirty INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE QuizSet ADD COLUMN bookmarksDirty INTEGER NOT NULL DEFAULT 0")
        db.execSQL("UPDATE QuizSet SET uid = lower(hex(randomblob(16)))")
        db.execSQL("ALTER TABLE Attempt ADD COLUMN uid TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE Attempt ADD COLUMN synced INTEGER NOT NULL DEFAULT 0")
        db.execSQL("UPDATE Attempt SET uid = lower(hex(randomblob(16)))")
    }
}

/** Triggers mark a set dirty whenever AI edits or bookmarks change a question — no call-site bookkeeping needed. */
val SyncTriggers = object : RoomDatabase.Callback() {
    override fun onOpen(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TRIGGER IF NOT EXISTS q_dirty AFTER UPDATE OF explanation, application, correct ON Question BEGIN UPDATE QuizSet SET dirty=1 WHERE id=NEW.quizSetId; END")
        db.execSQL("CREATE TRIGGER IF NOT EXISTS q_bm AFTER UPDATE OF bookmarked ON Question BEGIN UPDATE QuizSet SET bookmarksDirty=1 WHERE id=NEW.quizSetId; END")
    }
}
