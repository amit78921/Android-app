package com.quizapp.ui.importer

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.quizapp.ai.GeminiService
import com.quizapp.pdf.*
import kotlinx.coroutines.launch

class ImportViewModel(private val repo: ImportRepository, private val ai: GeminiService) : ViewModel() {
    var questions by mutableStateOf<List<ParsedQ>>(emptyList()); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    fun load(q: Uri, a: Uri?) = viewModelScope.launch {
        busy = true; error = null
        runCatching { repo.parse(q, a) }.onSuccess { questions = it; if (it.isEmpty()) error = "No questions found — try the other PDF or check its format." }
            .onFailure { error = it.message }
        busy = false
    }
    fun edit(i: Int, f: (ParsedQ) -> ParsedQ) { questions = questions.toMutableList().also { it[i] = f(it[i]) } }
    fun remove(i: Int) { questions = questions.toMutableList().also { it.removeAt(i) } }
    fun suggest(onResult: (Triple<String, String, String>) -> Unit) = viewModelScope.launch {
        busy = true; error = null
        runCatching { ai.hierarchy(questions.take(6).map { it.text }) }.onSuccess(onResult).onFailure { error = it.message }
        busy = false
    }
    fun save(s: String, t: String, st: String, title: String, done: () -> Unit) = viewModelScope.launch {
        repo.save(s.trim(), t.trim(), st.trim(), title.trim(), questions); done()
    }
}

@Composable
fun ImportScreen(vm: ImportViewModel, onSaved: () -> Unit) {
    var qUri by remember { mutableStateOf<Uri?>(null) }; var aUri by remember { mutableStateOf<Uri?>(null) }
    var subject by remember { mutableStateOf("") }; var topic by remember { mutableStateOf("") }
    var sub by remember { mutableStateOf("") }; var title by remember { mutableStateOf("") }
    val pickQ = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { qUri = it }
    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { aUri = it }
    val pdf = arrayOf("application/pdf")

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ pickQ.launch(pdf) }) { Text(if (qUri == null) "Question PDF" else "Question ✓") }
                OutlinedButton({ pickA.launch(pdf) }) { Text(if (aUri == null) "Answer PDF" else "Answer ✓") }
                Button({ qUri?.let { vm.load(it, aUri) } }, enabled = qUri != null && !vm.busy) { Text("Parse") }
            }
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
        if (vm.questions.isNotEmpty()) {
            item {
                TextButton({ vm.suggest { (s, t, st) -> subject = s; topic = t; sub = st } }) { Text("✨ Suggest subject / topic / subtopic with AI") }
                F("Subject", subject) { subject = it }; F("Major topic", topic) { topic = it }
                F("Subtopic", sub) { sub = it }; F("Quiz set title", title) { title = it }
                val ok = listOf(subject, topic, sub, title).all { it.isNotBlank() }
                Button({ vm.save(subject, topic, sub, title, onSaved) }, enabled = ok, modifier = Modifier.fillMaxWidth()) {
                    Text("Save ${vm.questions.size} questions (${vm.questions.count { it.flagged }} need review)")
                }
            }
            itemsIndexed(vm.questions) { i, q ->
                Card(colors = CardDefaults.cardColors(containerColor = if (q.flagged) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Q${q.number}", style = MaterialTheme.typography.labelLarge)
                        F("Question", q.text) { v -> vm.edit(i) { it.copy(text = v) } }
                        listOf("A", "B", "C", "D").forEachIndexed { k, l -> F("Option $l", q.opts[k]) { v -> vm.edit(i) { it.withOpt(k, v) } } }
                        F("Correct (A–D)", q.correct) { v -> vm.edit(i) { it.copy(correct = v.uppercase().take(1)) } }
                        F("Explanation (optional)", q.explanation) { v -> vm.edit(i) { it.copy(explanation = v) } }
                        TextButton({ vm.remove(i) }) { Text("Delete question") }
                    }
                }
            }
        }
    }
}

@Composable private fun F(label: String, v: String, on: (String) -> Unit) =
    OutlinedTextField(v, on, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
