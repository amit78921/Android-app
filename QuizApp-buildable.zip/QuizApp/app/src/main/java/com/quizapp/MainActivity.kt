package com.quizapp

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quizapp.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = (application as QuizApp).prefs
        setContent {
            val theme by prefs.theme.collectAsStateWithLifecycle(); val scale by prefs.fontScale.collectAsStateWithLifecycle(); val lang by prefs.lang.collectAsStateWithLifecycle()
            val dark = when (theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            val ctx = LocalContext.current; val d = LocalDensity.current
            val cs = when {
                Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                dark -> darkColorScheme(); else -> lightColorScheme()
            }
            CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * scale), LocalS provides if (lang == "hi") HI else EN) {
                MaterialTheme(colorScheme = cs) { Surface(Modifier.fillMaxSize()) { AppNav() } }
            }
        }
    }
}
