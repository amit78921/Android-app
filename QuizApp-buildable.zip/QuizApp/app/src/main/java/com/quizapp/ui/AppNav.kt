package com.quizapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import com.quizapp.auth.*
import com.quizapp.sync.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.*
import com.quizapp.QuizApp
import com.quizapp.ui.importer.*
import com.quizapp.ui.quiz.*

@Composable
fun AppNav() {
    val app = LocalContext.current.applicationContext as QuizApp; val dao = app.db.dao()
    val auth by app.auth.state.collectAsStateWithLifecycle()
    if (auth is AuthState.SignedOut) { LoginScreen(app.auth); return }
    val nav = rememberNavController()
    val online by app.net.online.collectAsStateWithLifecycle(true)
    val pending by remember { dao.pending() }.collectAsStateWithLifecycle(0)
    val signedIn = auth is AuthState.SignedIn
    LaunchedEffect(online, signedIn) { if (online && signedIn) SyncScheduler.enqueue(app) }     // sign-in, app start, connection restored
    LaunchedEffect(pending) { if (pending > 0 && online && signedIn) SyncScheduler.enqueue(app) } // new local changes
    val banner = when {
        !online -> "Offline — imported quizzes and saved explanations still work" + if (signedIn && pending > 0) ". $pending change(s) will sync when you're back online." else ""
        signedIn && pending > 0 -> "Syncing $pending change(s)…"
        else -> null
    }
    fun id(e: androidx.navigation.NavBackStackEntry) = e.arguments!!.getString("id")!!.toLong()

    Column(Modifier.fillMaxSize()) {
    banner?.let { Surface(color = if (!online) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
        Text(it, Modifier.statusBarsPadding().padding(8.dp), style = MaterialTheme.typography.labelMedium) } }
    Box(Modifier.weight(1f).then(if (banner != null) Modifier.consumeWindowInsets(WindowInsets.statusBars) else Modifier)) {
    NavHost(nav, "home") {
        composable("home") {
            val items by remember { dao.subjects() }.collectAsStateWithLifecycle(emptyList())
            ProgressList(LocalS.current.subjects, items, onImport = { nav.navigate("import") }, onSettings = { nav.navigate("settings") }, onAnalytics = { nav.navigate("analytics") }) { nav.navigate("topics/$it") }
        }
        composable("topics/{id}") { e ->
            val items by remember(e) { dao.majorTopics(id(e)) }.collectAsStateWithLifecycle(emptyList())
            ProgressList(LocalS.current.majorTopics, items, onBack = { nav.popBackStack() }) { nav.navigate("subtopics/$it") }
        }
        composable("subtopics/{id}") { e ->
            val items by remember(e) { dao.subtopics(id(e)) }.collectAsStateWithLifecycle(emptyList())
            ProgressList(LocalS.current.subtopics, items, onBack = { nav.popBackStack() }) { nav.navigate("sets/$it") }
        }
        composable("sets/{id}") { e ->
            val items by remember(e) { dao.quizSets(id(e)) }.collectAsStateWithLifecycle(emptyList())
            var pick by remember { mutableStateOf<Long?>(null) }; var mins by remember { mutableStateOf("") }
            ProgressList(LocalS.current.quizSets, items, onBack = { nav.popBackStack() }) { pick = it }
            pick?.let { setId ->
                fun start(mode: String) { nav.navigate("quiz/$setId/$mode/${mins.ifEmpty { "0" }}"); pick = null }
                AlertDialog(onDismissRequest = { pick = null }, title = { Text("Start quiz") },
                    text = { Column { OutlinedTextField(mins, { mins = it.filter(Char::isDigit).take(3) }, label = { Text("Timer in minutes (optional)") }, singleLine = true) } },
                    confirmButton = { Column { TextButton({ start("practice") }) { Text("Practice (instant feedback)") }; TextButton({ start("test") }) { Text("Test (feedback after submit)") } } },
                    dismissButton = { TextButton({ pick = null }) { Text("Cancel") } })
            }
        }
        composable("quiz/{setId}/{mode}/{mins}") { e ->
            val a = e.arguments!!
            val vm: QuizViewModel = viewModel(factory = viewModelFactory {
                initializer { QuizViewModel(dao, a.getString("setId")!!.toLong(), a.getString("mode") == "practice", a.getString("mins")!!.toInt(), app.gemini) }
            })
            QuizScreen(vm) { nav.popBackStack("home", false) }
        }
        composable("analytics") { AnalyticsScreen(dao, app.gemini) { nav.popBackStack() } }
        composable("settings") { SettingsScreen(app.keys, app.auth, app.prefs) { nav.popBackStack() } }
        composable("import") {
            val vm: ImportViewModel = viewModel(factory = viewModelFactory { initializer { ImportViewModel(app.importRepo, app.gemini) } })
            ImportScreen(vm) { nav.popBackStack() }
        }
    }
} }
}
