package com.quizapp.sync

import android.content.Context
import androidx.work.*
import com.quizapp.QuizApp
import java.util.concurrent.TimeUnit

/** Runs only when the network is up; failures retry with exponential backoff. Pending work lives in Room flags, so nothing is lost offline. */
class SyncWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = try {
        (applicationContext as QuizApp).sync.syncAll(); Result.success()
    } catch (e: Exception) { Result.retry() }
}

object SyncScheduler {
    fun enqueue(ctx: Context) = WorkManager.getInstance(ctx).enqueueUniqueWork("sync", ExistingWorkPolicy.APPEND_OR_REPLACE,
        OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build())
}
