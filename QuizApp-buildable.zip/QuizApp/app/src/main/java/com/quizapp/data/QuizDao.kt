package com.quizapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class Progress(val id: Long, val name: String, val total: Int, val attempted: Int, val accuracy: Double)

data class DayStat(val day: String, val total: Int, val correct: Int)
data class Overall(val total: Int, val acc: Double)
data class Names(val subject: String, val topic: String, val subtopic: String)
data class AttemptOut(val uid: String, val setUid: String, val number: Int, val selected: String, val isCorrect: Boolean, val timeMs: Long, val mode: String, val ts: Long)

private const val M = "COUNT(DISTINCT q.id) total, COUNT(DISTINCT a.questionId) attempted, COALESCE(AVG(a.isCorrect)*100.0,0) accuracy "
private const val QA = "LEFT JOIN Question q ON q.quizSetId=qs.id LEFT JOIN Attempt a ON a.questionId=q.id "

@Dao
interface QuizDao {
    @Query("SELECT s.id id, s.name name, $M FROM Subject s LEFT JOIN MajorTopic m ON m.subjectId=s.id LEFT JOIN Subtopic st ON st.majorTopicId=m.id LEFT JOIN QuizSet qs ON qs.subtopicId=st.id $QA GROUP BY s.id ORDER BY s.name")
    fun subjects(): Flow<List<Progress>>

    @Query("SELECT m.id id, m.name name, $M FROM MajorTopic m LEFT JOIN Subtopic st ON st.majorTopicId=m.id LEFT JOIN QuizSet qs ON qs.subtopicId=st.id $QA WHERE m.subjectId=:subjectId GROUP BY m.id ORDER BY m.name")
    fun majorTopics(subjectId: Long): Flow<List<Progress>>

    @Query("SELECT st.id id, st.name name, $M FROM Subtopic st LEFT JOIN QuizSet qs ON qs.subtopicId=st.id $QA WHERE st.majorTopicId=:topicId GROUP BY st.id ORDER BY st.name")
    fun subtopics(topicId: Long): Flow<List<Progress>>

    @Query("SELECT qs.id id, qs.title name, $M FROM QuizSet qs $QA WHERE qs.subtopicId=:subtopicId GROUP BY qs.id ORDER BY qs.createdAt DESC")
    fun quizSets(subtopicId: Long): Flow<List<Progress>>

    @Query("SELECT * FROM Question WHERE quizSetId=:setId ORDER BY number")
    suspend fun questions(setId: Long): List<Question>
    @Query("UPDATE Question SET bookmarked=:b WHERE id=:id") suspend fun bookmark(id: Long, b: Boolean)
    @Query("UPDATE Question SET explanation=:e, application=:a WHERE id=:id") suspend fun setExplanation(id: Long, e: String?, a: String?)
    @Insert suspend fun insert(a: Attempt)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(c: AiCache)
    @Query("SELECT response FROM AiCache WHERE key=:key") suspend fun cached(key: String): String?

    @Query("SELECT s.name || ' › ' || m.name || ' › ' || st.name FROM QuizSet qs JOIN Subtopic st ON st.id=qs.subtopicId JOIN MajorTopic m ON m.id=st.majorTopicId JOIN Subject s ON s.id=m.subjectId WHERE qs.id=:setId")
    suspend fun path(setId: Long): String?

    @Query("UPDATE Question SET correct=:c, needsReview=0 WHERE id=:id") suspend fun setCorrect(id: Long, c: String)
    @Query("SELECT subtopicId FROM QuizSet WHERE id=:id") suspend fun subtopicOfSet(id: Long): Long?

    // ---- analytics ----
    @Query("SELECT COUNT(*) total, COALESCE(AVG(isCorrect)*100.0,0) acc FROM Attempt") fun overall(): Flow<Overall>
    @Query("SELECT date(ts/1000,'unixepoch','localtime') day, COUNT(*) total, SUM(isCorrect) correct FROM Attempt GROUP BY day ORDER BY day DESC LIMIT 14") fun recentDays(): Flow<List<DayStat>>
    @Query("SELECT DISTINCT date(ts/1000,'unixepoch','localtime') FROM Attempt ORDER BY 1 DESC") fun activeDays(): Flow<List<String>>
    @Query("SELECT st.id id, s.name || ' › ' || st.name name, COUNT(*) total, COUNT(DISTINCT a.questionId) attempted, AVG(a.isCorrect)*100.0 accuracy FROM Attempt a JOIN Question q ON q.id=a.questionId JOIN QuizSet qs ON qs.id=q.quizSetId JOIN Subtopic st ON st.id=qs.subtopicId JOIN MajorTopic m ON m.id=st.majorTopicId JOIN Subject s ON s.id=m.subjectId GROUP BY st.id HAVING COUNT(*)>=5 ORDER BY accuracy ASC LIMIT 5")
    fun weakSubtopics(): Flow<List<Progress>>
    @Query("SELECT id FROM QuizSet WHERE subtopicId=:s LIMIT 1") suspend fun anySet(s: Long): Long?
    @Query("SELECT DISTINCT q.* FROM Question q JOIN Attempt a ON a.questionId=q.id JOIN QuizSet qs ON qs.id=q.quizSetId WHERE qs.subtopicId=:s AND a.isCorrect=0 LIMIT 8") suspend fun wrongInSubtopic(s: Long): List<Question>

    // ---- sync outbox / apply ----
    @Query("SELECT * FROM QuizSet WHERE dirty=1") suspend fun dirtySets(): List<QuizSet>
    @Query("SELECT * FROM QuizSet WHERE bookmarksDirty=1") suspend fun bookmarkDirtySets(): List<QuizSet>
    @Query("UPDATE QuizSet SET dirty=0 WHERE id=:id") suspend fun clearDirty(id: Long)
    @Query("UPDATE QuizSet SET bookmarksDirty=0 WHERE id=:id") suspend fun clearBmDirty(id: Long)
    @Query("SELECT bookmarksDirty FROM QuizSet WHERE id=:id") suspend fun bmDirty(id: Long): Boolean
    @Query("SELECT s.name subject, m.name topic, st.name subtopic FROM QuizSet qs JOIN Subtopic st ON st.id=qs.subtopicId JOIN MajorTopic m ON m.id=st.majorTopicId JOIN Subject s ON s.id=m.subjectId WHERE qs.id=:id")
    suspend fun names(id: Long): Names?
    @Query("SELECT number FROM Question WHERE quizSetId=:id AND bookmarked=1") suspend fun bookmarkedNumbers(id: Long): List<Int>
    @Query("SELECT a.uid uid, qs.uid setUid, q.number number, a.selected selected, a.isCorrect isCorrect, a.timeMs timeMs, a.mode mode, a.ts ts FROM Attempt a JOIN Question q ON q.id=a.questionId JOIN QuizSet qs ON qs.id=a.quizSetId WHERE a.synced=0 LIMIT 400")
    suspend fun unsyncedAttempts(): List<AttemptOut>
    @Query("UPDATE Attempt SET synced=1 WHERE uid IN (:uids)") suspend fun markSynced(uids: List<String>)
    @Query("SELECT id FROM QuizSet WHERE uid=:uid") suspend fun setIdByUid(uid: String): Long?
    @Query("SELECT id FROM Question WHERE quizSetId=:s AND number=:n") suspend fun questionId(s: Long, n: Int): Long?
    @Query("SELECT COUNT(*) FROM Attempt WHERE uid=:uid") suspend fun attemptCount(uid: String): Int
    @Query("UPDATE Question SET bookmarked=(number IN (:nums)) WHERE quizSetId=:setId") suspend fun applyBookmarks(setId: Long, nums: List<Int>)
    @Query("SELECT (SELECT COUNT(*) FROM QuizSet WHERE dirty=1 OR bookmarksDirty=1) + (SELECT COUNT(*) FROM Attempt WHERE synced=0)") fun pending(): Flow<Int>

    // import helpers (get-or-create hierarchy)
    @Query("SELECT id FROM Subject WHERE name=:n LIMIT 1") suspend fun subjectId(n: String): Long?
    @Query("SELECT id FROM MajorTopic WHERE subjectId=:p AND name=:n LIMIT 1") suspend fun topicId(p: Long, n: String): Long?
    @Query("SELECT id FROM Subtopic WHERE majorTopicId=:p AND name=:n LIMIT 1") suspend fun subtopicId(p: Long, n: String): Long?
    @Insert suspend fun insert(s: Subject): Long
    @Insert suspend fun insert(m: MajorTopic): Long
    @Insert suspend fun insert(s: Subtopic): Long
    @Insert suspend fun insert(q: QuizSet): Long
    @Insert suspend fun insertQuestions(q: List<Question>)
}

@Database(entities = [Subject::class, MajorTopic::class, Subtopic::class, QuizSet::class, Question::class, Attempt::class, AiCache::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() { abstract fun dao(): QuizDao }
