package com.quizapp.ai

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.generationConfig
import com.quizapp.data.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Verdict(val agrees: Boolean, val answer: String, val reason: String)

/**
 * All Gemini features. Every text answer is cached in Room (AiCache), so each prompt hits the network once.
 * [allowed] is the guest-mode gate — Phase 4 passes "user is signed in".
 */
class GeminiService(private val keys: SecureKeyStore, private val dao: QuizDao, private val allowed: () -> Boolean = { true }) {
    companion object { const val MODEL = "gemini-2.5-pro" }   // change here if you want another Pro model
    private val lang = "Reply in the same language as the question (Hindi or English)."
    private fun Question.block() = "Question: $text\nA) $optA\nB) $optB\nC) $optC\nD) $optD\nMarked answer: $correct"

    private suspend fun gen(json: Boolean, prompt: String): String {
        if (!allowed()) error("AI features need sign-in (not available in guest mode).")
        val key = keys.get() ?: error("Add your Gemini API key in Settings first.")
        val m = GenerativeModel(MODEL, key, generationConfig = generationConfig { temperature = 0.3f; if (json) responseMimeType = "application/json" })
        val t = m.generateContent(prompt).text ?: error("Empty AI response")
        return t.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    }
    private suspend fun cached(key: String, json: Boolean, prompt: String, force: Boolean = false) =
        (if (force) null else dao.cached(key)) ?: gen(json, prompt).also { dao.put(AiCache(key, it)) }

    /** Generate (or, with force, improve) Explanation + Application and store them on the question. */
    suspend fun explain(q: Question, force: Boolean = false): Pair<String, String> {
        val j = JSONObject(cached("explain:${q.id}", true,
            "You are an expert exam tutor. For this MCQ return JSON {\"explanation\":\"why the marked answer is correct and why each other option is not\",\"application\":\"real-world or exam-oriented use of the concept\"}. Be concise. $lang\n\n${q.block()}", force))
        val e = j.getString("explanation"); val a = j.getString("application")
        dao.setExplanation(q.id, e, a); return e to a
    }

    /** Independent answer check — use when the PDF answer looks inconsistent. */
    suspend fun verify(q: Question): Verdict {
        val j = JSONObject(cached("verify:${q.id}", true,
            "Solve this MCQ independently, ignoring the marked answer. Return JSON {\"answer\":\"A|B|C|D\",\"reason\":\"one or two sentences\"}. $lang\n\n${q.block()}"))
        val a = j.getString("answer").trim().take(1).uppercase()
        return Verdict(a == q.correct, a, j.getString("reason"))
    }

    /** Ask-AI follow-up doubts on one question. */
    suspend fun ask(q: Question, history: List<Pair<String, String>>, msg: String): String {
        val ctx = history.joinToString("\n") { "Student: ${it.first}\nTutor: ${it.second}" }
        val p = "You are a patient exam tutor. MCQ under discussion:\n${q.block()}\nExplanation: ${q.explanation ?: "-"}\n\n$ctx\nStudent: $msg\nTutor (concise): $lang"
        return cached("chat:${q.id}:${p.hashCode()}", false, p)
    }

    /** Auto-tag: suggest Subject / Major Topic / Subtopic from a few sample questions. */
    suspend fun hierarchy(samples: List<String>): Triple<String, String, String> {
        val p = "Classify these exam questions. Return JSON {\"subject\":\"\",\"topic\":\"\",\"subtopic\":\"\"} using short, standard syllabus names.\n" + samples.take(6).joinToString("\n") { "- $it" }
        val j = JSONObject(cached("tag:${p.hashCode()}", true, p))
        return Triple(j.getString("subject"), j.getString("topic"), j.getString("subtopic"))
    }

    /** New practice set (same subtopic) targeting concepts from the questions the student got wrong. */
    suspend fun practice(setId: Long, wrong: List<Question>, n: Int = 10): Long {
        val sub = dao.subtopicOfSet(setId) ?: error("Quiz set not found")
        val p = "Create $n new MCQs with 4 options for: ${dao.path(setId).orEmpty()}. The student is weak on concepts like:\n" + wrong.take(8).joinToString("\n") { "- ${it.text}" } +
            "\nReturn JSON {\"questions\":[{\"text\":\"\",\"a\":\"\",\"b\":\"\",\"c\":\"\",\"d\":\"\",\"correct\":\"A|B|C|D\",\"explanation\":\"\",\"application\":\"\"}]}. Do not repeat the given questions. $lang"
        val arr = JSONObject(gen(true, p)).getJSONArray("questions")
        val id = dao.insert(QuizSet(subtopicId = sub, title = "AI Practice · " + SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date())))
        dao.insertQuestions((0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Question(quizSetId = id, number = i + 1, text = o.getString("text"), optA = o.getString("a"), optB = o.getString("b"), optC = o.getString("c"), optD = o.getString("d"),
                correct = o.getString("correct").trim().take(1).uppercase(), explanation = o.optString("explanation").ifBlank { null }, application = o.optString("application").ifBlank { null })
        })
        return id
    }

    /** Weak-topic practice from the Analytics screen: targets questions previously answered wrong in this subtopic. */
    suspend fun practiceForSubtopic(subtopicId: Long): Long = practice(dao.anySet(subtopicId) ?: error("No quiz set in this subtopic"), dao.wrongInSubtopic(subtopicId))
}
