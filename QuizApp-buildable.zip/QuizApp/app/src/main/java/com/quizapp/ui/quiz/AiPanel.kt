package com.quizapp.ui.quiz

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.quizapp.data.Question

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiActions(vm: QuizViewModel, q: Question) {
    var ask by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (q.explanation == null) Button({ vm.explain(false) }, enabled = !vm.aiBusy) { Text("Generate with AI") }
            else TextButton({ vm.explain(true) }, enabled = !vm.aiBusy) { Text("Improve with AI") }
            TextButton({ vm.verify() }, enabled = !vm.aiBusy) { Text("Verify answer") }
            TextButton({ ask = true }) { Text("Ask AI") }
        }
        if (vm.aiBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.aiError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        vm.verdicts[vm.index]?.let { v ->
            Text(if (v.agrees) "✓ AI agrees with ${q.correct}. ${v.reason}" else "⚠ AI suggests ${v.answer} (PDF says ${q.correct}). ${v.reason}")
            if (!v.agrees) TextButton({ vm.useAiAnswer() }) { Text("Use AI's answer") }
        }
    }
    if (ask) AskSheet(vm) { ask = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AskSheet(vm: QuizViewModel, onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    ModalBottomSheet(onClose) {
        Column(Modifier.padding(16.dp).heightIn(max = 480.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.chats[vm.index].orEmpty()) { (u, a) -> Column { Text("You: $u", fontWeight = FontWeight.Bold); Text(a) } }
            }
            if (vm.aiBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.aiError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Ask a doubt…") })
                IconButton({ vm.ask(text.trim()); text = "" }, enabled = text.isNotBlank() && !vm.aiBusy) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
            }
        }
    }
}

@Composable
fun PracticeFromMistakes(vm: QuizViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Button({ vm.practiceFromMistakes() }, enabled = !vm.aiBusy, modifier = Modifier.fillMaxWidth()) { Text("Generate AI practice from my mistakes") }
        if (vm.aiBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.practiceMsg?.let { Text(it) }
        vm.aiError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
