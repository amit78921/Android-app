package com.quizapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quizapp.ai.GeminiService
import com.quizapp.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.roundToInt

/** (current, best) streak of consecutive active days. [days] are ISO dates, newest first. */
fun streaks(days: List<String>): Pair<Int, Int> {
    val d = days.map(LocalDate::parse).sortedDescending(); if (d.isEmpty()) return 0 to 0
    var best = 1; var run = 1
    for (i in 1 until d.size) { run = if (d[i] == d[i - 1].minusDays(1)) run + 1 else 1; best = maxOf(best, run) }
    var cur = 0
    if (d[0] >= LocalDate.now().minusDays(1)) { cur = 1; for (i in 1 until d.size) if (d[i] == d[i - 1].minusDays(1)) cur++ else break }
    return cur to best
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(dao: QuizDao, ai: GeminiService, onBack: () -> Unit) {
    val S = LocalS.current; val scope = rememberCoroutineScope()
    val overall by remember { dao.overall() }.collectAsStateWithLifecycle(Overall(0, 0.0))
    val days by remember { dao.recentDays() }.collectAsStateWithLifecycle(emptyList())
    val dates by remember { dao.activeDays() }.collectAsStateWithLifecycle(emptyList())
    val weak by remember { dao.weakSubtopics() }.collectAsStateWithLifecycle(emptyList())
    var msg by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    val (cur, best) = remember(dates) { streaks(dates) }
    Scaffold(topBar = { TopAppBar(title = { Text(S.analytics) }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                    Text("${overall.total} ${S.attempts} · ${overall.acc.roundToInt()}% ${S.accuracy}", style = MaterialTheme.typography.titleMedium)
                    Text("${S.streak}: $cur 🔥   ·   ${S.bestStreak}: $best")
                } }
            }
            item {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(S.last14, style = MaterialTheme.typography.labelLarge)
                    if (days.isEmpty()) Text(S.noData) else Trend(days.reversed())
                } }
            }
            item { Text(S.weakTopics, style = MaterialTheme.typography.titleMedium) }
            items(weak, key = { it.id }) { w ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                    Text(w.name, style = MaterialTheme.typography.titleSmall)
                    Text("${w.accuracy.roundToInt()}% · ${w.total} ${S.attempts}", style = MaterialTheme.typography.bodySmall)
                    TextButton({ busy = true; msg = null
                        scope.launch { runCatching { ai.practiceForSubtopic(w.id) }.onSuccess { msg = "AI practice set created for ${w.name}" }.onFailure { msg = it.message }; busy = false } }, enabled = !busy) { Text(S.practiceAi) }
                } }
            }
            item { if (busy) LinearProgressIndicator(Modifier.fillMaxWidth()); msg?.let { Text(it) } }
        }
    }
}

@Composable
private fun Trend(days: List<DayStat>) {
    val bar = MaterialTheme.colorScheme.primary; val track = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
        val w = size.width / days.size
        days.forEachIndexed { i, d ->
            val h = size.height * d.correct / d.total
            drawRect(track, Offset(i * w + 3, 0f), Size(w - 6, size.height)); drawRect(bar, Offset(i * w + 3, size.height - h), Size(w - 6, h))
        }
    }
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(days.first().day.drop(5), style = MaterialTheme.typography.labelSmall); Text(days.last().day.drop(5), style = MaterialTheme.typography.labelSmall) }
}
