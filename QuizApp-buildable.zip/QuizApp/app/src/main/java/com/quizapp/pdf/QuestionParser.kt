package com.quizapp.pdf

data class ParsedQ(val number: Int, val text: String, val a: String = "", val b: String = "", val c: String = "", val d: String = "",
                   val correct: String = "", val explanation: String = "") {
    val opts get() = listOf(a, b, c, d)
    val flagged get() = correct.isEmpty() || opts.any { it.isBlank() } || text.isBlank()
    fun withOpt(i: Int, v: String) = when (i) { 0 -> copy(a = v); 1 -> copy(b = v); 2 -> copy(c = v); else -> copy(d = v) }
}

/** Letter → 0..3. Accepts A-D, a-d, and Hindi labels (अ ब स द / क ख ग घ). */
fun optIndex(ch: Char): Int = "ABCD".indexOf(ch.uppercaseChar()).takeIf { it >= 0 }
    ?: "अबसद".indexOf(ch).takeIf { it >= 0 } ?: "कखगघ".indexOf(ch)

object QuestionParser {
    private val qRe = Regex("""^\s*(?:Q(?:uestion)?\.?\s*|प्रश्न\s*)?(\d{1,3})\s*[.)]\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val oRe = Regex("""^\s*\(?([A-Da-dअबसदकखगघ])[.)]\s*(.*)$""")

    fun parse(raw: String): List<ParsedQ> {
        val out = mutableListOf<ParsedQ>(); var opt = -1
        for (line in raw.lines().map { it.trim() }.filter { it.isNotEmpty() }) {
            val cur = out.lastOrNull(); val o = oRe.matchEntire(line); val q = qRe.matchEntire(line)
            val n = q?.groupValues?.get(1)?.toInt()
            when {
                // option line (only after a question started)
                o != null && cur != null -> { opt = optIndex(o.groupValues[1][0]); out[out.lastIndex] = cur.withOpt(opt, o.groupValues[2]) }
                // new question: number must advance (guards against "1. 2. 3." statements inside a question)
                q != null && (cur == null || n!! > cur.number && n <= cur.number + 3) -> { out += ParsedQ(n!!, q.groupValues[2]); opt = -1 }
                cur == null -> {}
                opt >= 0 -> out[out.lastIndex] = cur.withOpt(opt, (cur.opts[opt] + " " + line).trim())
                else -> out[out.lastIndex] = cur.copy(text = cur.text + " " + line)
            }
        }
        return out
    }
}

object AnswerParser {
    private val entry = Regex("""^\s*(\d{1,3})\s*[-.):]+\s*(?:Ans(?:wer)?\s*[:\-]?\s*|उत्तर\s*[:\-]?\s*)?\(?([A-Da-dअबसदकखगघ])\)?(?![A-Za-z])\s*(.*)$""", RegexOption.IGNORE_CASE)
    private val key = Regex("""(?<!\d)(\d{1,3})\s*[-.):]*\s*\(?([A-Da-d])\)?(?![A-Za-z])""")

    /** number → (A..D, explanation). Handles "12. B  <explanation…>" blocks and compact grids like "1-B 2-C 3-A". */
    fun parse(raw: String): Map<Int, Pair<String, String>> {
        val m = linkedMapOf<Int, Pair<String, String>>(); var last = -1
        for (line in raw.lines().map { it.trim() }.filter { it.isNotEmpty() }) {
            val e = entry.matchEntire(line)
            if (e != null) {
                last = e.groupValues[1].toInt()
                m[last] = "ABCD"[optIndex(e.groupValues[2][0])].toString() to e.groupValues[3]
            } else if (last >= 0) m[last] = m[last]!!.let { it.first to (it.second + " " + line).trim() }
        }
        if (m.size < 5) key.findAll(raw).forEach { m.putIfAbsent(it.groupValues[1].toInt(), it.groupValues[2].uppercase() to "") }
        return m
    }

    fun merge(qs: List<ParsedQ>, ans: Map<Int, Pair<String, String>>) =
        qs.map { q -> ans[q.number]?.let { q.copy(correct = it.first, explanation = it.second) } ?: q }
}
