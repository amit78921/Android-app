package com.quizapp.ai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Gemini key lives in EncryptedSharedPreferences (AES-256, master key held in Android Keystore). Never hardcoded, never synced. */
class SecureKeyStore(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "secure_prefs", MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun get(): String? = prefs.getString("gemini", null)
    fun set(k: String) = prefs.edit().putString("gemini", k.trim()).apply()
    fun clear() = prefs.edit().remove("gemini").apply()
}
