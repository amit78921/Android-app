package com.quizapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.quizapp.auth.AuthManager
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(auth: AuthManager) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Quiz", style = MaterialTheme.typography.displaySmall)
        Spacer(Modifier.height(12.dp))
        Text("Sign in to sync progress, bookmarks and imported quizzes across devices, and to use AI features.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button({ busy = true; err = null; scope.launch { runCatching { auth.signIn(ctx) }.onFailure { err = it.message ?: "Sign-in failed" }; busy = false } },
            enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Continue with Google") }
        TextButton({ auth.continueAsGuest() }) { Text("Continue as guest (no sync, no AI)") }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
