package com.quizapp.ui.quiz

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import com.quizapp.ui.LocalS
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Green = Color(0xFFC8E6C9); private val Red = Color(0xFFFFCDD2)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(vm: QuizViewModel, onExit: () -> Unit) {
    if (vm.finished) { ResultScreen(vm, onExit); return }
    if (vm.questions.isEmpty()) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }; return }
    val i = vm.index; val q = vm.questions[i]; val last = vm.questions.lastIndex
    val sel = vm.answers[i]; val locked = vm.locked(i); var palette by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Q${i + 1}/${vm.questions.size}" + if (vm.timed) "   ⏱ %d:%02d".format(vm.remaining / 60, vm.remaining % 60) else "") },
                actions = {
                    if (!vm.practice) TextButton({ vm.finish() }) { Text(LocalS.current.submit) }
                    IconButton({ vm.toggleBookmark() }) { Icon(if (q.bookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder, "Bookmark") }
                    IconButton({ palette = true }) { Icon(Icons.Filled.GridView, "Question palette") }
                })
        },
        bottomBar = {
            BottomAppBar {
                OutlinedButton({ vm.go(i - 1) }, enabled = i > 0, modifier = Modifier.padding(start = 16.dp)) { Text(LocalS.current.previous) }
                Spacer(Modifier.weight(1f))
                if (i < last) Button({ vm.go(i + 1) }, modifier = Modifier.padding(end = 16.dp)) { Text(LocalS.current.next) }
                else Button({ vm.finish() }, modifier = Modifier.padding(end = 16.dp)) { Text(if (vm.practice) LocalS.current.finish else LocalS.current.submit) }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(q.text, style = MaterialTheme.typography.titleMedium)
            listOf("A" to q.optA, "B" to q.optB, "C" to q.optC, "D" to q.optD).forEach { (l, t) ->
                val bg = when {
                    locked && l == q.correct -> Green
                    locked && l == sel -> Red
                    l == sel -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                val fg = if (locked && (l == q.correct || l == sel)) Color.Black else MaterialTheme.colorScheme.onSurface
                Card(onClick = { vm.answer(l) }, enabled = !locked, colors = CardDefaults.cardColors(bg, fg, bg, fg), modifier = Modifier.fillMaxWidth()) {
                    Text("$l.  $t", Modifier.padding(14.dp))
                }
            }
            if (locked) Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Block(LocalS.current.correctAnswer, "${q.correct}. " + when (q.correct) { "A" -> q.optA; "B" -> q.optB; "C" -> q.optC; else -> q.optD })
                    Block(LocalS.current.explanation, q.explanation ?: "Not generated yet.")
                    Block(LocalS.current.application, q.application ?: "Not generated yet.")
                    AiActions(vm, q)
                }
            }
        }
    }

    if (palette) ModalBottomSheet({ palette = false }) {
        LazyVerticalGrid(GridCells.Adaptive(52.dp), Modifier.heightIn(max = 420.dp).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(vm.questions) { k, qq ->
                val a = vm.answers[k]
                val c = when {
                    k == vm.index -> MaterialTheme.colorScheme.primary
                    a != null && vm.practice -> if (a == qq.correct) Green else Red
                    a != null -> MaterialTheme.colorScheme.secondaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(c).clickable { vm.go(k); palette = false }, Alignment.Center) {
                    Text("${k + 1}", color = if (k == vm.index) MaterialTheme.colorScheme.onPrimary else if (a != null && vm.practice) Color.Black else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

@Composable private fun Block(title: String, body: String) {
    Column { Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary); Text(body) }
}

@Composable
fun ResultScreen(vm: QuizViewModel, onExit: () -> Unit) {
    val ctx = LocalContext.current; val S = LocalS.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> ResultPdf.write(o, vm.reportBlocks(S)) } } }
    val n = vm.questions.size; val answered = vm.answers.size
    val correct = vm.answers.count { (k, l) -> vm.questions[k].correct == l }
    val wrong = vm.answers.filter { (k, l) -> vm.questions[k].correct != l }.keys.sorted()
    val acc = if (answered == 0) 0 else correct * 100 / answered; val secs = vm.totalMs / 1000
    Scaffold { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text(LocalS.current.result, style = MaterialTheme.typography.headlineMedium)
                Text("${LocalS.current.score}: $correct / $n", style = MaterialTheme.typography.titleLarge)
                Text("${LocalS.current.accuracy}: $acc%   ·   ${LocalS.current.time}: %d:%02d".format(secs / 60, secs % 60))
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Breakdown", style = MaterialTheme.typography.labelLarge)
                        Text(vm.path)
                        Text("Correct $correct · Wrong ${answered - correct} · Skipped ${n - answered}")
                    }
                }
            }
            item { Text(if (wrong.isEmpty()) "No wrong answers 🎉" else "Wrong-answer review", style = MaterialTheme.typography.titleMedium) }
            items(wrong) { k ->
                val q = vm.questions[k]
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Q${q.number}. ${q.text}")
                        Text("Your answer: ${vm.answers[k]}   Correct: ${q.correct}", color = MaterialTheme.colorScheme.error)
                        q.explanation?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            item { OutlinedButton({ export.launch("quiz-result.pdf") }, Modifier.fillMaxWidth()) { Text(S.exportPdf) } }
            item { if (wrong.isNotEmpty()) PracticeFromMistakes(vm) }
            item { Button(onExit, Modifier.fillMaxWidth()) { Text(LocalS.current.backHome) } }
        }
    }
}
