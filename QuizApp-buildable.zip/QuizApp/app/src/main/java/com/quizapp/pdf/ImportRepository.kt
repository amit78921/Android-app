package com.quizapp.pdf

import android.net.Uri
import androidx.room.withTransaction
import com.quizapp.data.*

class ImportRepository(private val db: AppDatabase, private val ex: PdfTextExtractor) {
    suspend fun parse(qUri: Uri, aUri: Uri?): List<ParsedQ> {
        val q = ex.extract(qUri)
        val qs = listOf(q.flat, q.columns).map(QuestionParser::parse).maxBy { l -> l.count { it.a.isNotBlank() && it.d.isNotBlank() } }
        if (aUri == null) return qs
        val a = ex.extract(aUri)
        val ans = listOf(a.flat, a.columns).map(AnswerParser::parse).maxBy { it.size }
        return AnswerParser.merge(qs, ans)
    }

    /** Creates Subject/Topic/Subtopic if missing, then the quiz set. Blank explanations stay null (Gemini fills them in Phase 3). */
    suspend fun save(subject: String, topic: String, subtopic: String, title: String, qs: List<ParsedQ>): Long = db.withTransaction {
        val d = db.dao()
        val s = d.subjectId(subject) ?: d.insert(Subject(name = subject))
        val t = d.topicId(s, topic) ?: d.insert(MajorTopic(subjectId = s, name = topic))
        val st = d.subtopicId(t, subtopic) ?: d.insert(Subtopic(majorTopicId = t, name = subtopic))
        val set = d.insert(QuizSet(subtopicId = st, title = title))
        d.insertQuestions(qs.map { Question(quizSetId = set, number = it.number, text = it.text, optA = it.a, optB = it.b, optC = it.c, optD = it.d,
            correct = it.correct, explanation = it.explanation.ifBlank { null }, needsReview = it.flagged) })
        set
    }
}
